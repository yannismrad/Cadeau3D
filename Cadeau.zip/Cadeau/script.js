/**
* Tu veux vraiment essayer de lire tout �a ? x)
*/

/** Variables globales */
var renderer, scene, camera, timer, 
skybox, camPivot, activeCamEnabled, rotatingCameras, msgMesh, pinkMesh, rotatingMsg, pivotMsg, snowmen, 
objects, particleSystem, rotatingObjects, pivots, lights;
var mouseX, mouseY;


/** Fonction d'initialisation de la sc�ne */
function init()
{
	//Listeners de clic de souris
	document.addEventListener( 'mousedown', onDocumentMouseClick, false );

	//WebGL	
	renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(document.body.clientWidth, document.body.clientHeight);
	document.body.appendChild(renderer.domElement);
	renderer.setClearColor(0xAAAAAA, 1.0);
	renderer.clear();
	
	//Initialisation de la sc�ne et des diff�rents tableaux d'objets (lumi�res, objets en rotation ...)
	scene = new THREE.Scene();
	camera = new THREE.PerspectiveCamera(50, window.innerWidth / window.innerHeight, 0.1, 10000 );
	objects = new Array();
	lights = new Array();
	pivots = new Array();
	rotatingObjects = new Array();
	rotatingMsg = new Array();
	pivotsMsg = new Array();
	arrowPivots = new Array();
	rotatingCameras = new Array();
	timer = new THREE.Clock();
	snowmen = new Array();
	
	//Projecteur de clic dans l'espace 3D
	projector = new THREE.Projector();
	
	//Cr�ation du d�cor
	createSkybox();
	createLights();
	createTerrain();
	createBall();
	createCandy(-300,100,200,0,0,0,1,1,1, 150);
	createCandy(200,140,400,0,0,0.3,1,1,1, 150);
	createCandy(100,140,-450,0,0,-0.3,2,3,1, 150);
	createCandy(-50,-10,500,0,0,0.3,2,3,2, 100);
	
	createPineTree(-400,100,-75,0,0.3,0);
	createPineTree(400,100,-700,0.2,0.3,0);
	createPineTree(550,150,500,-0.1,0.3,0);
	createPineTree(-600,120,600,-0.3,0.3,0);
	
	createSnowmen();
	setSnowmanPosition();
	createParticles();
	createCadeaux();
	
	setObjectsRotation();

	setUpCameras(1); //0 = cam�ra libre, 1 = cam�ra cin�matique qui tourne autour de la tour
	
	counter = 0; //compteur pour le d�placement de la cam�ra cin�matique
	speedFactor = Math.random() * (0.09 - 0.01) + 0.01;
	for(var j=0;j<pivots.length;j++)
	{
			pivots[j].speed= Math.random() * (0.02 - 0.005) + 0.005; //valeur al�atoire pour la vitesse de rotation des objets
	}

	/** Fonction de rendu de la sc�ne */
	function render() {
		requestAnimationFrame(render);

		//R�cup�ration du temps courant (pour l'animation de la texture d'eau)
		var delta = timer.getDelta();
		
		/* Rotation des objets autour de la sc�ne*/
		for(var j=0;j<pivots.length;j++)
		{
			pivots[j].rotation.y += pivots[j].speed; //Faire tourner tous les pivots centraux des objets
		}
		
		for(var i=0; i< rotatingObjects.length;i++)
		{
			rotatingObjects[i].rotation.y += speedFactor; //Faire tourner les pivots des objets
		}
		
		/* Rotation des particules */
		if(particleSystem != "undefined")
		{
			if(particleSystem.position.y<-500)
			{
				particleSystem.position.y+=200;
			}
				
			particleSystem.position.y -= 1.;
		}
		
		/* Rotation de la cam�ra active autour de la sc�ne*/
		if(activeCamEnabled)
		{
			var inc = Math.PI * 2 / 500; //incr�ment de d�placement vertical de la cam�ra
			rotatingCameras[0].position.y = 10 *Math.sin( counter);
			rotatingCameras[0].position.z = 0.3 * Math.sin( counter);
			rotatingCameras[0].rotation.x  = 0.02 * Math.sin( counter);
			counter += inc;
			camera.lookAt(new THREE.Vector3(0.0,10,-80.0));
			pivotRot.rotation.y -= 0.001;
			
			pinkMesh.quaternion.copy(pivotRot.quaternion); //panthere doit faire face a la camera en mouvement
		}
		
		else
		{
			pinkMesh.lookAt(camera.position);
		}
		
		renderer.render(scene, camera);
		
	};
	render();
}

/**Listener de clic de la souris */
function onDocumentMouseClick( event ) {
//TODO
}


/**
Cr�ation d'un cube servant de skybox (background de la sc�ne)
*/
function createSkybox()
{
	//Variables uniformes envoy�s au shader
	uniforms = {
	
		amplitude: {
			type: 'f', // a float
			value: 0
		},
		time : {
			type: 'f',
			value: 0.0
		}
	};
	
	//textures de la skybox
    var path = "textures/skybox/";
    var format = '.png';
    var urls = [
    path + 'mpa105ft' + format, path + 'mpa105bk' + format,
    path + 'mpa105up' + format, path + 'mpa105dn' + format,
    path + 'mpa105rt' + format, path + 'mpa105lf' +format];
	
    var cubemap = THREE.ImageUtils.loadTextureCube(urls);
	cubemap.format = THREE.RGBFormat;

	var shader = THREE.ShaderLib['cube']; // utilisation d'un shader fourni par Three.js pour le chargement de textures de cube
	shader.uniforms['tCube'].value = cubemap; //envoi des textures au shader
	
	var shaderMaterial = new THREE.ShaderMaterial({
			fragmentShader: shader.fragmentShader,
			vertexShader: shader.vertexShader,
			uniforms: shader.uniforms,
			depthWrite: false,
			side: THREE.BackSide //afficher les textures "� l'int�rieur" du cube
	});
	
	var skybox = new THREE.Mesh(new THREE.CubeGeometry(8000, 8000, 8000),shaderMaterial);
    scene.add(skybox);
}


/** Cr�er la boule a neige et ses �l�ments */
function createBall()
{
	addSphere();
	addBase();
	addPlaque();
	createPinky();
	createSnowmen();
	createStaticCadeaux(); 
	createPineTree(70,120,-75,-0.2,0,0);
}

/** La boule */
function addSphere()
{
		/** Sph�re */
	geoBall= new THREE.SphereGeometry(160, 16, 16);
	meshBall = new THREE.Mesh(geoBall, new THREE.MeshPhongMaterial({color: 0xffffff, transparent : true, opacity : 0.2}));
	meshBall.position.x = 90;
	meshBall.position.y = 130;
	meshBall.renderDepth = -1.1; //n�cessaire pour que pinky ne disparaisse pas sous certains angles
	scene.add(meshBall);
}

/** Base de la boule */
function addBase()
{
	texPath = "textures/objects/other/wood.jpg";
		
		//Variables uniformes (texture, position de la cam�ra et de la lumi�re)
		var uniformsBase = 
		{
			texture:
			{
				type:'t',
				value: new THREE.ImageUtils.loadTexture(texPath)
			},
			cameraPosition:
			{
				type:'v3',
				value: camera.position
			},
			lightPosition:
			{
				type:'v3',
				value: lights[0].position 
			}
		};
		
		//Shader du pied de la boule
		var shaderBase= new THREE.ShaderMaterial({
			uniforms: uniformsBase,
			vertexShader: document.getElementById( 'vertexShaderItems' ).textContent,
			fragmentShader: document.getElementById( 'fragmentShaderItems' ).textContent
		});
	
	geoBallBase = new THREE.CylinderGeometry(165, 200, 70, 12, 30, false) ;
	ballBase = new THREE.Mesh( geoBallBase, shaderBase);
	ballBase.position.x = 90;
	ballBase.position.y = 0;
	scene.add(ballBase);
	
	/** Tas de neige dans la boule */
	snowBall= new THREE.SphereGeometry(140,16,16, Math.PI/2, Math.PI*2, 0, Math.PI);
	var mat = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		normalMap: new THREE.ImageUtils.loadTexture("textures/terrain/snow_norm.png"), 
		bumpscale: 1.0,
		shininess: 50,
		
	});
	//mat.side = THREE.BackSide;
	meshSnowBall = new THREE.Mesh(snowBall, mat );
	meshSnowBall.position.x = 90;
	meshSnowBall.position.y = -30;
	scene.add(meshSnowBall);
}

/** Plaque sur la base de la boule */
function addPlaque()
{
	//Base de la plaque
	var geoPlaque= new THREE.CubeGeometry( 70, 64,10,10 );
	var materialPlaque = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		side : THREE.DoubleSide,
		transparent : true,
		map : new THREE.ImageUtils.loadTexture("textures/objects/other/wood.jpg")
	});
	
	plaqueMesh = new THREE.Mesh( geoPlaque, materialPlaque);
	plaqueMesh.position.x = 40;
	plaqueMesh.position.y = 0;
	plaqueMesh.position.z = 170;
	plaqueMesh.rotation.y = -0.25;
	plaqueMesh.rotation.z = -0.1;
	plaqueMesh.rotation.x = -0.5;
	scene.add(plaqueMesh);
	
	//Texte de la plaque
	var geoPlaqueTexte= new THREE.PlaneGeometry( 70, 64,10,10 );
	var materialPlaqueTexte = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		side : THREE.DoubleSide,
		transparent : true,
		map : new THREE.ImageUtils.loadTexture("textures/objects/other/plaque.png"),
		normalMap: new THREE.ImageUtils.loadTexture("textures/objects/other/plaque_norm.png")
	});
	
	plaqueTexteMesh = new THREE.Mesh( geoPlaqueTexte, materialPlaqueTexte);
	plaqueTexteMesh.position.x = 39;
	plaqueTexteMesh.position.y = 3;
	plaqueTexteMesh.position.z = 174.3;
	plaqueTexteMesh.rotation.y = -0.25;
	plaqueTexteMesh.rotation.z = -0.1;
	plaqueTexteMesh.rotation.x = -0.5;
	scene.add(plaqueTexteMesh);
}

/**
* Position du bonhomme de neige dans la boule
*/
function setSnowmanPosition()
{
	snowmen[0].position.x = 7;
	snowmen[0].position.y = 70;
	snowmen[0].position.z = 0;
	snowmen[0].rotation.z = 0.5;
	
	snowmen[1].position.x = -50;
	snowmen[1].position.y = -110;
	snowmen[1].position.z = 400;
	snowmen[1].rotation.y = 2.7;
}

/** Cr�er des bonhommes de neige :) */
function createSnowmen()
{
	bodySize = 32;
	geoBody= new THREE.SphereGeometry(bodySize, 12, 16);
	geoMiddle = new THREE.SphereGeometry(bodySize*2/3, 12, 16);
	geoHead = new THREE.SphereGeometry(bodySize/2, 12, 16);
	
	var material = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		map : new THREE.ImageUtils.loadTexture("textures/objects/snowman/snowman.png"), 
		normalMap: new THREE.ImageUtils.loadTexture("textures/objects/snowman/snowman_norm.png"), 
		bumpscale: 10.0,
		shininess: 50,
		
	});
	
	body = new THREE.Mesh(geoBody, material);
	middle = new THREE.Mesh(geoMiddle, material);
	head = new THREE.Mesh(geoHead, material);
	
	body.add(middle);
	middle.add(head);
	middle.position.y = 45;
	head.position.y = 30;
	scene.add(body);
	snowmen.push(body);
	
	decorateSnowman(head, middle, body);
}

/** Cr�er un sapin */
function createPineTree(posX, posY, posZ, rotX, rotY, rotZ)
{
	texTrunkPath = "textures/objects/tree/trunk.png";
	texLeavesPath = "textures/objects/tree/leaves.png";
	
		var uniformsTrunk = 
		{
			texture:
			{
				type:'t',
				value: new THREE.ImageUtils.loadTexture(texTrunkPath)
			},
			cameraPosition:
			{
				type:'v3',
				value: camera.position
			},
			lightPosition:
			{
				type:'v3',
				value: lights[0].position 
			}
		};
		
		//Shader du tronc
		var shaderTrunk= new THREE.ShaderMaterial({
			uniforms: uniformsTrunk,
			vertexShader: document.getElementById( 'vertexShaderItems' ).textContent,
			fragmentShader: document.getElementById( 'fragmentShaderItems' ).textContent
		});
		
		var materialLeaves = new THREE.MeshPhongMaterial( 
		{ 
			map : new THREE.ImageUtils.loadTexture("textures/objects/tree/leaves.png"), 
			normalMap : new THREE.ImageUtils.loadTexture("textures/objects/tree/leaves_norm.png"),
			bumpscale: 2,
			shininess: 50,
		});
	
	/** Tronc */
	geoTrunk = new THREE.CylinderGeometry(12, 20, 100, 32, 30, false) ;
	trunkMesh = new THREE.Mesh( geoTrunk, shaderTrunk);
	trunkMesh.position.x = posX;
	trunkMesh.position.y = posY;
	trunkMesh.position.z = posZ;
	trunkMesh.rotation.x = rotX;
	trunkMesh.rotation.y = rotY;
	trunkMesh.rotation.z = rotZ;
	scene.add(trunkMesh);
	
	/** Feuillage */
	geoLeaves = new THREE.CylinderGeometry(1, 40, 100, 32, 30, false) ;
	leavesMesh = new THREE.Mesh( geoLeaves, materialLeaves);
	trunkMesh.add(leavesMesh);
	leavesMesh.position.y = 60;
	
}

/** Ajouter des yeux, une bouche, un chapeau au bonhomme de neige */
function decorateSnowman(head, middle, body)
{
	/* Yeux */
	geoEye = new THREE.SphereGeometry(2, 10, 16);
	var material = new THREE.MeshPhongMaterial( 
	{ 
		color: 0x000000,
		specular: 0xffffff,
        emissive: 0x000000,
        shininess: 100 ,		
		map : new THREE.ImageUtils.loadTexture("textures/objects/snowman/black.png"), 		
	});
	
	var carotteMaterial = new THREE.MeshPhongMaterial( 
	{ 
		specular: 0xffffff,
        shininess: 100 ,		
		map : new THREE.ImageUtils.loadTexture("textures/objects/snowman/carot.png"), 	
		normalMap : new THREE.ImageUtils.loadTexture("textures/objects/snowman/carot_norm.png"),
		bumpscale: 2.0
	});
	
	eyeL = new THREE.Mesh(geoEye, material);
	eyeR = new THREE.Mesh(geoEye, material);
	
	eyeL.position.z = 15;
	eyeL.position.y = 3;
	eyeL.position.x = -5;
	
	eyeR.position.z = eyeL.position.z;
	eyeR.position.y = eyeL.position.y;
	eyeR.position.x = -eyeL.position.x;
	head.add(eyeL);
	head.add(eyeR);
	
	/* Bouche */
	geoMouth = new THREE.SphereGeometry(1, 10, 16);
	s1 = new THREE.Mesh(geoMouth, material);
	s2 = new THREE.Mesh(geoMouth, material);
	s3 = new THREE.Mesh(geoMouth, material);
	s4 = new THREE.Mesh(geoMouth, material);
	s5 = new THREE.Mesh(geoMouth, material);
	s6 = new THREE.Mesh(geoMouth, material);
	s7 = new THREE.Mesh(geoMouth, material);
	s8 = new THREE.Mesh(geoMouth, material);
	
	s1.position.z = 12;
	s1.position.y = -2;
	s1.position.x = -10;
	
	s2.position.z = s1.position.z;
	s2.position.y = s1.position.y;
	s2.position.x = -s1.position.x;
	
	s3.position.z = 13;
	s3.position.y = -5;
	s3.position.x = -7;
	
	s4.position.z = s3.position.z;
	s4.position.y = s3.position.y;
	s4.position.x = -s3.position.x;
	
	s5.position.z = 14;
	s5.position.y = -6;
	s5.position.x = -4;
	
	s6.position.z = s5.position.z;
	s6.position.y = s5.position.y;
	s6.position.x = -s5.position.x;
	
	s7.position.z = 15;
	s7.position.y = -6.5;
	s7.position.x = -1.5;
	
	s8.position.z = s7.position.z;
	s8.position.y = s7.position.y;
	s8.position.x = -s7.position.x;
	
	head.add(s1);
	head.add(s2);
	head.add(s3);
	head.add(s4);
	head.add(s5);
	head.add(s6);
	head.add(s7);
	head.add(s8);
	
	/* Carotte */
	carotteGeo = new THREE.CylinderGeometry(2, 0, 12, 12, 12, false);
	carotte = new THREE.Mesh(carotteGeo,carotteMaterial);
	carotte.position.z = 22;
	carotte.rotation.x = -1.555;
	head.add(carotte);
	
	/*Chapeau */
	cylindreGeo = new THREE.CylinderGeometry(7, 7, 20, 50, 50, false);
	//(bottomRadius, topRadius, height, segmentsRadius, segmentsHeight)
	cylindre = new THREE.Mesh(cylindreGeo,material);
	
	head.add(cylindre);
	cylindre.position.y = 20;
	baseGeo = new THREE.CylinderGeometry(10, 10, 5, 50, 50, false);
    cylindreBase = new THREE.Mesh(baseGeo,material); 
	cylindre.add(cylindreBase);
	cylindreBase.position.y = -6;
	
	/* Boutons */
	b1 = new THREE.Mesh(geoEye, material);
	b2 = new THREE.Mesh(geoEye, material);
	
	b1.position.z = 18;
	b1.position.y = 10;
	b2.position.z = 20;
	
	middle.add(b1);
	middle.add(b2);
}

/** Une p'tite panthere rose :) */
function createPinky()
{
	var geoPink= new THREE.PlaneGeometry( 100, 64,10,10 );
	var materialPink = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		side : THREE.DoubleSide,
		transparent : true,
		map : new THREE.ImageUtils.loadTexture("textures/objects/other/pinkie.png")
	});
	
	pinkMesh = new THREE.Mesh( geoPink, materialPink);
	pinkMesh.position.x = 100;
	pinkMesh.position.y = 136;
	pinkMesh.position.z = 10;
	
	scene.add(pinkMesh);
}

/**
* Cr�er des cannes � sucres
*/
function createCandy(x,y,z, rX,rY,rZ, scaleX, scaleY, scaleZ, size)
{
	var candyMat = new THREE.MeshPhongMaterial( 
	{ 
		color: 0xffffff, 
		map : new THREE.ImageUtils.loadTexture("textures/objects/other/candy.png"), 
		normalMap: new THREE.ImageUtils.loadTexture("textures/objects/other/candy_norm.png"), 
		bumpscale: 5.0,
		shininess: 50,
	});
	
	var geoCandy = new THREE.CylinderGeometry(12, 12, size, 32, 30, false) ;
	candyMesh = new THREE.Mesh( geoCandy, candyMat);
	
	candyMesh.position.x = x;
	candyMesh.position.y = y;
	candyMesh.position.z = z;
	candyMesh.rotation.x = rX;
	candyMesh.rotation.y = rY;
	candyMesh.rotation.z = rZ;
	candyMesh.scale.x = scaleX;
	candyMesh.scale.y = scaleY;
	candyMesh.scale.z = scaleZ;
	
	scene.add(candyMesh);
}

/** Terrain */
function createTerrain()
{
	 // texture used to generate "bumpiness"
	var bumpTexture = new THREE.ImageUtils.loadTexture( 'textures/terrain/heightmap.png' );
	bumpTexture.wrapS = bumpTexture.wrapT = THREE.RepeatWrapping;
	// magnitude of normal displacement
	var bumpScale = 600.0; 
	
	var snowIcyTexture = new THREE.ImageUtils.loadTexture( 'textures/terrain/snowice.png' );
	snowIcyTexture.wrapS = snowIcyTexture.wrapT = THREE.RepeatWrapping;
	
	var snowyTexture = new THREE.ImageUtils.loadTexture( 'textures/terrain/snow.png' );
	snowyTexture.wrapS = snowyTexture.wrapT = THREE.RepeatWrapping; 
	
	var rockyTexture = new THREE.ImageUtils.loadTexture( 'textures/terrain/snowrock.png' );
	rockyTexture.wrapS = rockyTexture.wrapT = THREE.RepeatWrapping;
	
	// use "this." to create global object
	this.customUniforms = {
	bumpTexture: { type: "t", value: bumpTexture },
	bumpScale: { type: "f", value: bumpScale },
	oceanTexture: { type: "t", value: snowIcyTexture },
	sandyTexture: { type: "t", value: snowyTexture},
	grassTexture: { type: "t", value: rockyTexture },
	rockyTexture: { type: "t", value: rockyTexture},
	snowyTexture: { type: "t", value: snowyTexture },
	lightPosition: { type: "v3", value: lights[0].position}
	}; 
	
	
	// create custom material from the shader code above
	// that is within specially labelled script tags
	var customMaterial = new THREE.ShaderMaterial(
	{
	uniforms: customUniforms,
	vertexShader: document.getElementById( 'vertexShader' ).textContent,
	fragmentShader: document.getElementById( 'fragmentShader' ).textContent,
	} );
		
	var planeGeo = new THREE.PlaneGeometry( 1500, 1500, 100, 100 );
	var plane = new THREE.Mesh( planeGeo, customMaterial );
	plane.rotation.x = -Math.PI / 2;
	plane.position.y = -400;
	scene.add( plane ); 
}

/**
* Cadeaux qui volent
*/
function createCadeaux()
{
	nb = (Math.random()* (3 - 10 +1)) + 10;

	for(var i=0;i<nb;i++)
	{
		var cubeSize = 20;
		var geoGift= new THREE.CubeGeometry(cubeSize,cubeSize,cubeSize) ;
		
		randTextureNumber = Math.floor(Math.random() * 3) + (1); //texture 1 2 ou 3 pour les cadeaux
		texPath = "textures/objects/gift/g"+randTextureNumber+".png";
	
		var uniformsGift= 
		{
			texture:
			{
				type:'t',
				value: new THREE.ImageUtils.loadTexture(texPath)
			},

			cameraPosition:
			{
				type:'v3',
				value: camera.position
			},
			
			lightPosition:
			{
				type:'v3',
				value: lights[0].position 
			}
		};
		
		//Shader des cadeaux
		var shaderGift= new THREE.ShaderMaterial({
			uniforms: uniformsGift,
			vertexShader: document.getElementById( 'vertexShaderItems' ).textContent,
			fragmentShader: document.getElementById( 'fragmentShaderItems' ).textContent
		});
		
		gift = new THREE.Mesh( geoGift, shaderGift);
		
		//Position et rotation al�atoires
		gift.position.x = Math.floor(Math.random() * 150) + (-300); //Max + min
		gift.position.y = Math.floor(Math.random() * 150) + (200);
		gift.position.z = Math.floor(Math.random() * 150) + (-300);
		
		gift.rotation.x = Math.random() * (1.0 - 0.001) + 0.1;
		gift.rotation.z = Math.random() * (1.0 - 0.001) + 0.1;
		
		scale = Math.floor(Math.random() * 1.5) + (1.0);
		gift.scale.x = scale;
		gift.scale.y = scale;
		gift.scale.z = scale;
		
		rotatingObjects.push(gift);
		scene.add(gift);
	}
	
}

/** Cadeaux dans la boule */
function createStaticCadeaux()
{
	var cubeSize = 20;
	var geoGift= new THREE.CubeGeometry(cubeSize,cubeSize,cubeSize);

		var mat1= new THREE.MeshPhongMaterial( 
		{ 
			color: 0xffffff, 
			specular: 0xffffff,
			map : new THREE.ImageUtils.loadTexture("textures/objects/gift/g1.png"), 
			normalMap : new THREE.ImageUtils.loadTexture("textures/objects/gift/g_norm.png"), 
			bumpscale : 1.5			
		});
		
		var mat2= new THREE.MeshPhongMaterial( 
		{ 
			color: 0xffffff, 
			specular: 0xffffff, 
			map : new THREE.ImageUtils.loadTexture("textures/objects/gift/g2.png"), 
			normalmap : new THREE.ImageUtils.loadTexture("textures/objects/gift/g_norm.png"), 
			bumpscale : 1.5
		});
		
		var mat3= new THREE.MeshPhongMaterial( 
		{ 
			color: 0xffffff, 
			specular: 0xffffff,
			map : new THREE.ImageUtils.loadTexture("textures/objects/gift/g3.png"), 
			normalmap: new THREE.ImageUtils.loadTexture("textures/objects/gift/g_norm.png"), 
			bumpscale : 1.5
		});
		
		c1 = new THREE.Mesh( geoGift, mat1);
		c2 = new THREE.Mesh( geoGift, mat2);
		c3 = new THREE.Mesh( geoGift, mat3);
		
		c1.position.x =50;
		c1.position.y =90;
		c1.position.z =80;
		c1.scale.x = 2.0;
		c1.scale.y = 2.0;
		c1.scale.z = 2.0;
		c1.rotation.x = 0.4;
		c1.rotation.y = 0.5;
		c1.rotation.z = 0.2;
		
		c2.position.x =150;
		c2.position.y =75;
		c2.position.z =90;
		c2.scale.y = 2.0;
		c2.rotation.x = 0.5;
		c2.rotation.y = 0;
		c2.rotation.z = -0.4;
		
		c3.position.x =200;
		c3.position.y =65;
		c3.position.z =0;
		
		c3.rotation.x = 0;
		c3.rotation.y = 0;
		c3.rotation.z = 0.8;

		scene.add(c1);
		scene.add(c2);
		scene.add(c3);
		
}

/** Cr�ation de particules flottantes (neige)*/
function createParticles()
{
	particles = new THREE.Geometry();
	nbParticles = Math.random() * (1000- (150)) + 150; //Nombre de particules al�atoire
	var particleSize;
	for (var i = 0; i < nbParticles; i++) 
	{
		var particle = new THREE.Vector3(Math.random() * 900 - 300, Math.random() * 700 - 100, Math.random() * 1000 - 300);
		particleSize = Math.random() * (6 - (4)) + 4; //Taille des particules al�atoire
		particles.vertices.push(particle);
	}
	
	var particleTex = THREE.ImageUtils.loadTexture('textures/particles/particle.png'); //utilisation d'une texture
	var particleMaterial = new THREE.ParticleBasicMaterial({ map: particleTex, transparent: true, size: particleSize, emissive : 0xffffff});
	particleSystem = new THREE.ParticleSystem(particles, particleMaterial);
	particleSystem.position.y = 300;
	scene.add(particleSystem);
}

/**Ajout de pivots pour les objets devant faire des rotations autour de la tour (1 pivot central par objet + 1 pivot d'objet) */
function setObjectsRotation()
{
	for(var i=0;i<rotatingObjects.length;i++)
	{
		pivot = new THREE.Object3D(); //Objet abstrait plac� au centre de la sc�ne qui va servir de pivot de rotation
		scene.add(pivot);
		pivotObject = new THREE.Object3D(); //Pivot attach� � l'objet
		pivotObject.add(rotatingObjects[i]);
		pivot.add(pivotObject); //le pivot de l'objet est attach� au pivot central
		pivots.push(pivot);
	}
}

/** Chargement des lumi�res */
function createLights()
{
	var light = new THREE.PointLight(); //Une lumi�re ponctuelle principale
	light.position.set(500, 500, 505);
	light.intensity = 0.5;
	
	light2 = new THREE.PointLight();
	light2.position.set(-500,500,-505);
	light2.intensity = 0.4;
	var ambientLight = new THREE.AmbientLight(0xaaaaaa); //une lumi�re ambiante
	lights.push(light);
	lights.push(ambientLight);
	lights.push(light2);
	rotatingObjects.push(light);
	rotatingObjects.push(light2);

	for(var i=0;i<lights.length;i++)
	{
		scene.add(lights[i]);
	}
}

/**R�glages de cam�ra (libre avec orbit controls ou cam�ra qui se d�place seule) */
function setUpCameras(activeCam)
{
	switch(activeCam)
	{
		//Cam�ra libre (orbit controls)
		case 0:
			activeCamEnabled = false;
			camera.position.x = 83;
			camera.position.y = 134;
			camera.position.z = 341;
			camera.lookAt (new THREE.Vector3 (0.0, 0.0, 0.0));
			var controls = new THREE.OrbitControls( camera , renderer.domElement );
			break;
			
		//Cam�ra qui se d�place selon un sch�ma donn�
		case 1:
			activeCamEnabled = true;
			createActiveCam();
			break;
			
		default:
			break;
	}
}

/** Animation d'une cam�ra fixe autour de la tour */
function createActiveCam()
{
	camera.lookAt (new THREE.Vector3 (100, 136, 10));
	
	camPivot = new THREE.Object3D();
	camPivot.add(camera);
	pivotRot = new THREE.Object3D();
	pivotRot.add(camPivot);
	scene.add(pivotRot);
	rotatingCameras.push(camera);
	
	//Position de d�part de la cam�ra
	camPivot.position.x = 100;
	camPivot.position.z = 300;
	camPivot.position.y = 100;
	camPivot.rotation.x = -0.3;
	
	rotatingCameras[0].position.y = 130; 
	rotatingCameras[0].position.z = 300; 
	//rotatingCameras[0].rotation.x = -0.5; 
}
